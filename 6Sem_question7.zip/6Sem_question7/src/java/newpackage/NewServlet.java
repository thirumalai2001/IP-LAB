/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author barun
 */
public class NewServlet extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String firstname = request.getParameter("fname");
            String designation = request.getParameter("desg");
            String address1 = request.getParameter("add1");
            String address2 = request.getParameter("add2");
            String city = request.getParameter("city");
            String state = request.getParameter("state");
            String emailid = request.getParameter("emailid");
            addressBook obj = new addressBook(firstname, designation, address1, address2, city, state, emailid);
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Register for mailing lists</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Successfully registered !</h1>");
            out.println("<h2>First name : " + obj.firstname + "</h2>");
            out.println("<h2>Designation : " + obj.designation + "</h2>");
            out.println("<h2>Address 1 : " + obj.address1 + "</h2>");
            out.println("<h2>Address 2 : " + obj.address2 + "</h2>");
            out.println("<h2>City : " + obj.city + "</h2>");
            out.println("<h2>State : " + obj.state + "</h2>");
            out.println("<h2>Email ID : " + obj.emailid + "</h2>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

class addressBook {
    String firstname;
    String designation;
    String address1;
    String address2;
    String city;
    String state;
    String emailid;
    addressBook(String f, String d, String a1, String a2, String c, String s, String e) {
        firstname = f;
        designation = d;
        address1 = a1;
        address2 = a2;
        city = c;
        state = s;
        emailid = e;
    }
}
